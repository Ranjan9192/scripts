# -*- coding: utf-8 -*-
"""
Created on Wed Oct  4 16:40:52 2017

@author: ranshara
"""

import pandas
import sys
#from pandas.tools.plotting import scatter_matrix
#import matplotlib.pyplot as plt
#from sklearn import model_selection
#from sklearn.metrics import classification_report
#from sklearn.metrics import confusion_matrix
#from sklearn.metrics import accuracy_score

#from sklearn.tree import DecisionTreeClassifier
#from sklearn.neighbors import KNeighborsClassifier
#from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
#from sklearn.naive_bayes import GaussianNB
#from sklearn.svm import SVC


def loadDataSet(file_name, data_set_attr):
    '''Method to Load Data Set From url or FilePath'''
    dataset = pandas.read_csv(filename, names=data_set_attr)
    return dataset


def Get_Dimensions_DataSet(dataset):
    '''Method to get the Data Set's Size/Dimension'''
    return dataset.shape

def getFirstNDataSetFromTop(dataSet, NoLinesFromTop):
    if len(dataset) < NoLinesFromTop:
        return dataSet.head(NoLinesFromTop)
    else :
        return dataset.head(len(dataset))
    
def describeDataSet(dataset):
    '''Method to get Descriptive Analytics of the DataSet'''
    return dataset.describe()


comment = '''loading the Data Set'''

print(comment)
#Driver code to Load Data From File
filename = "./iris.data"
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
names = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
dataset = loadDataSet(filename, names)

    
#get the Dimension Of the Data Set  ----- Start
#print("Dimension of Data Set", Get_Dimensions_DataSet(dataset))
#get the Dimension Of the Data Set  ----- End


#print the Data
NoofLinesFromTop = 10
#print("Printing ",NoofLinesFromTop," from Top\n",getFirstNDataSetFromTop(dataset,NoofLinesFromTop))

print("Descriptive Analysis Of DataSet ")


# descriptions
print(describeDataSet(dataset))# class distribution

#print("Griop By")
#print(dataset.groupby('class').size())



import matplotlib.pyplot as plt
#‘bar’ or ‘barh’ for bar plots
#‘hist’ for histogram
#‘box’ for boxplot
#‘kde’ or 'density' for density plots
#‘area’ for area plots
#‘scatter’ for scatter plots
#‘hexbin’ for hexagonal bin plots
#‘pie’ for pie plots

def plotDataSet(dataframe, kindofplot, subplots, layoutXY, shareX, shareY):
    '''Method to Plot DataSet
    dataset:DataFrame Object
    kindofplot =    ‘bar’ or ‘barh’ for bar plots
                    ‘hist’ for histogram
                    ‘box’ for boxplot
                    ‘kde’ or 'density' for density plots
                    ‘area’ for area plots
                    ‘scatter’ for scatter plots
                    ‘hexbin’ for hexagonal bin plots
                    ‘pie’ for pie plots
    '''
    dataframe.plot(kind=kindofplot, subplots=subplots, layout=layoutXY, sharex=shareX, sharey=shareY)
    plt.show()

#Driver Code to test DF Plot
plotDataSet(dataset, 'box', True, (2,2), False, False)



from pandas.plotting import scatter_matrix
# scatter plot matrix
scatter_matrix(dataset)
plt.show()

from sklearn import model_selection
# Split-out validation dataset
array = dataset.values #Convert dataset into numpy 2d array which return type is DataFrame into

X = array[:,0:4] #split numpy 2d matrix [row:range,col:range]
Y = array[:, 4]
validation_size = 0.20 #default value of test_size=0.25(iccase of None)
seed = 7 # it's generate Random number for data selection on splited array
X_train, X_validation, Y_train, Y_validation = model_selection.train_test_split(X, Y, test_size=validation_size, random_state=seed)

#build Models
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC


models = []
models.append(('LR', LogisticRegression()))
models.append(('LDA', LinearDiscriminantAnalysis()))
models.append(('KNN', KNeighborsClassifier()))
models.append(('CART', DecisionTreeClassifier()))
models.append(('NB', GaussianNB()))
models.append(('SVM', SVC()))
# evaluate each model in turn
results = []
names = []

title="%s\t %s\t %s" % ("Algo ", "Mean Value","   Std")
#sys.stdout.write("--") #without new line
print(title)
    
for name, model in models:
    kfold = model_selection.KFold(n_splits=10, random_state=seed)
    cv_results = model_selection.cross_val_score(model, X_train, Y_train, cv=kfold, scoring = 'accuracy')
    results.append(cv_results)
    names.append(name)
    #msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
    msg = "%s:\t %f\t (%f)" % (name, cv_results.mean(), cv_results.std())
    print(msg)





