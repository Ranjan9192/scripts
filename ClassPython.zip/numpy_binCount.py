# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
# Python Program explaining 
# working of numpy.bincount() method
 
import numpy as geek
 
# 1D array with +ve integers

array1 = ['1','3', '1', '3', '1', '2', '99999999']
array2 = [10, 11, 4, 6, 2, 1, 19]
 
# array2 : weight
bin = geek.bincount(array1, array2,100)
print("Summation element-wise : \n", len(bin))