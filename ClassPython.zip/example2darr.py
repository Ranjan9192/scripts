# -*- coding: utf-8 -*-
"""
Created on Thu Oct  5 16:01:28 2017

@author: ranshara
"""
import numpy as np
arr = [[1 ,2, 3, 4],
       [4, 5 ,6, 10],
       [9 ,8 ,7, 23]]

#X = arr[1, 0:1]
print(arr)

y=np.array(arr)

print(y)

Z = y[1:2, :]
print("Slice array=",Z)