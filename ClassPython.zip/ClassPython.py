#jshjdh

class MyClass:
    name = ''
    lastname = ''
    
    
    def __init__(self):
        self.name = name
        lastname=name


    def __init__(self,xyz,abc):
        pass
       

        
    def printName(self):
        self.name = "Amith"
        self.lastname="Singh"
        
        return  (self.lastname='')

m=MyClass('Amith',"Singh")
print(m.printName())




class Myclass2:

      def __init__(self,title):
        self.title=title



m=Myclass2('Mr')
print(m.title)
