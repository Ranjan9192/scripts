##squares = []
##for x in range(5):
##    squares.append(lambda n=x: n**2)
##
##for y in squares:
##    print(y())


squares = [2,6]


##for x in squares: 
##    print(x())
    
for x in squares:
    squares.append(lambda: x**2)

for x in range(5):
    print (x())



    
